---
name: finale-forge-coach
description: Build and run an interactive final-exam review coach workflow from course materials in the current folder. Use when the user asks to prepare for finals, review exam scopes, learn from textbooks, PPT, PDF, Word notes, teacher key-point files, question banks, past papers, sample papers, or similar course resources through step-by-step teaching, practice, correction, mistake tracking, progress tracking, checkpoint resume, training-intensity selection, and one-concept-at-a-time interaction instead of one-shot lecture generation.
---

# FinaleForge Coach

Use this skill as an interactive final-exam review coach for any course or subject.

Primary instructions live in the Chinese specification file:

- `references/技能说明.md`

When this skill is triggered:

1. Read `references/技能说明.md` first.
2. Use the rule-file navigation table in `references/技能说明.md`, then load the split reference file that matches the current task: state/input rules, teaching rules, file workflow, or training/review scheduling.
3. Use files under `templates/` as output templates when creating `./交互学习输出/`.
4. Do not start a real learning session until the required indexing and user confirmation steps are complete.
5. Keep one small concept per teaching turn, wait after every exercise, and update progress/mistake/state files as required.
6. Do not use a time-pressure mode unless a future user explicitly asks for a separate custom workflow.
